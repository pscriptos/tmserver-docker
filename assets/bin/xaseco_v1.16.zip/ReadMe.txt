This is a modified version of xaseco 1.16!
It has been modified for php7.X.
The original version of xaseco 1.16 only runs with php5.6.

The original version can still be downloaded here:
https://www.xaseco.org

Code of customization and help can be found here:
http://www.tm-forum.com/viewtopic.php?f=127&t=35817&sid=7f741b0a9337904e8d81c8a6672c277c
http://www.tm-forum.com/viewtopic.php?f=127&t=37120&sid=eeacbab49c56864a3d5283a300354b41
https://ftp.bueddl.de/tm/php7_patches/

Uploaded & Hosted by Hoerli.NET
https://hoerli.net/sdm_downloads/xaseco1-modifiziert-fuer-php7-x/