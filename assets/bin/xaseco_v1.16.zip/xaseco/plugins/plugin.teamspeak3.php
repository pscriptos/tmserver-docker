<?php
/*
 #  Teamspeak 3 version 0.6
 #	by Reaby
*/

require_once('includes/xmlparser.inc.php');
require_once("includes/tsstatus.php");

Aseco::registerEvent('onSync', 'ts3_startup');
Aseco::registerEvent('onNewChallenge', 'ts3_panel_on');
Aseco::registerEvent('onPlayerConnect', 'ts3_panel_on');
Aseco::registerEvent('onEverySecond', 'ts3_update');
Aseco::registerEvent('onPlayerManialinkPageAnswer', 'ts3_mania_event');

global $aseco, $ts3, $ts3_counter, $ts3_settings;

// Initialize
function ts3_startup($aseco, $command) 
{
	global $aseco, $ts3, $ts3_counter, $ts3_settings, $ts3_channel;;
	
	$ts3_counter = 0;
	$ts3 = new Teamspeak3();
	
	// load config
	$xml_parser = new Examsly();
	if ($settings = $xml_parser->parseXml('teamspeak3.xml')) {
		$ts3_settings = array();
		$ts3_settings['server_addr'] = $settings['SETTINGS']['SERVER'][0];
		$ts3_settings['serverid'] = $settings['SETTINGS']['SERVERID'][0];
		$ts3_settings['serverport'] = $settings['SETTINGS']['SERVERPORT'][0];
		$ts3_settings['queryport'] = $settings['SETTINGS']['QUERYPORT'][0];
		$ts3_settings['channel'] = $settings['SETTINGS']['DEFAULTCHANNEL'][0];
		$ts3_settings['subchannel'] = $settings['SETTINGS']['SUBCHANNEL'][0];
		$ts3_settings['channelpassword'] = $settings['SETTINGS']['CHANNELPASSWORD'][0];
		$ts3_settings['helperURL'] = $settings['SETTINGS']['HELPERURL'][0];
		$ts3_settings['logoURL'] =  $settings['SETTINGS']['LOGOURL'][0];
		$ts3_settings['posx'] =  $settings['SETTINGS']['POSX'][0];
		$ts3_settings['posy'] =  $settings['SETTINGS']['POSY'][0];
		$ts3_settings['update_interval'] = $settings['SETTINGS']['UPDATE_INTERVAL'][0];
		
	} 
	else 
	{
		trigger_error('[plugin.teamspeak3.php] Could not read/parse setttings file version.xml!', E_USER_WARNING);
		return false;
	}
	
	$ts3->Aseco = $aseco;
	$ts3->Start();
	$ts3->visibility = true;
}



function ts3_update($aseco, $command) {
	global $ts3, $ts3_counter, $ts3_settings;
	$time = time();
	if ($time >= $ts3_counter) 
		{         
			$ts3->tsstatus->update();
			if ($ts3->visibility) 
			{ 
				$ts3->panel_on(); 
			}
			$ts3_counter = $time + $ts3_settings['update_interval'];
		}
}



function ts3_panel_on($aseco, $command) 
{
	global $ts3;
	$ts3->visibility = true;
	$ts3->panel_on();
}



function ts3_panel_off($aseco, $command) 
{
	global $ts3;
	$ts3->visibility = false;
	$ts3->panel_off();
}


function ts3_mania_event($aseco, $command) 
{
	global $ts3;
	$login = $command[1];
	$action = $command[2];
	if ($action == $ts3->manialinkID+1) {
		$ts3->info_on($login);
	}

	if ($action == $ts3->manialinkID+2) {
		$ts3->info_off($login);
	}

}

 
class Teamspeak3 {
	public $aseco;
	public $tsstatus;
	public $manialinkID = 35790;
	public $visibility = true;
	
	
	function Start() 
	{
		global $ts3_settings;
		$this->tsstatus = new TSStatus($ts3_settings['server_addr'], $ts3_settings['queryport'], $ts3_settings['serverid']);
	}
		
	function panel_off() 
	{
		$xml = '<?xml version="1.0" encoding="UTF-8"?><manialinks><manialink id='.$this->manialinkID.'></manialink></manialinks>';
		$this->Aseco->addCall('SendDisplayManialinkPage', array($xml, 0, false));
	}
	
	function panel_on() {
		global $ts3_settings;
		$xml = '
		<?xml version="1.0" encoding="UTF-8"?>
			<manialinks>
		    <manialink id="'.$this->manialinkID.'">
		    	<frame posn="'.$ts3_settings['posx'].' '.$ts3_settings['posy'].' 0">
		    		<quad sizen="3 3" posn="0 0 0.001" image="'. $ts3_settings['logoURL'] .'" action="'.($this->manialinkID+1).'" />
				</frame>
				<frame posn="'.($ts3_settings['posx'] + 3).' '.$ts3_settings['posy'].' 0">
		        	<quad sizen="9 3" posn="0 0 0.001" style="BgRaceScore2" substyle="BgScores" action="'.($this->manialinkID+1).'"/>
				<format textsize="1"/>';
		
		$i = 0;
		unset($message);
		$users = $this->tsstatus->_serverDatas['virtualserver_clientsonline'] - 1;
		$max = $this->tsstatus->_serverDatas['virtualserver_maxclients'];
		$message = "\$fff ".$users." / ".$max;
		
		$xml .= '<label sizen="30 2" halign="left" posn="1 -0.9 0.1" text="'.$message.'"/>';

		$xml .='</frame>
		     </manialink>
		     </manialinks>';
		
		$this->Aseco->addCall('SendDisplayManialinkPage', array($xml, 0, false));
	}
	

	function info_on($login) {
		global $ts3_settings;
				
		$player = $this->Aseco->server->players->getPlayer($login);
		$style = $player->style;
		$widths[0] = 1.5;
		$header = "Teamspeak 3 Status";
		$button = "Close";
		$hsize = $style['HEADER'][0]['TEXTSIZE'][0];
		$bsize = $style['BODY'][0]['TEXTSIZE'][0];
		$lines = 23;
		$stats = array();
		
		//build manialink header & window
		$xml = '<?xml version="1.0" encoding="UTF-8"?>
		            <manialinks>
		               <manialink id="'.($this->manialinkID+4).'">
		                  <frame pos="' . ($widths[0]/2) . ' 0.47 0">' .
		                     '<quad size="' . $widths[0] . ' ' . (0.11+$hsize+$lines*$bsize) .
		                     '" style="' . $style['WINDOW'][0]['STYLE'][0] .
		                     '" substyle="' . $style['WINDOW'][0]['SUBSTYLE'][0] . '"/>' . LF;
		
		//add header and optional icon
		$xml .= '<quad pos="-' . ($widths[0]/2) . ' -0.01 -0.1" size="' . ($widths[0]-0.02) . ' ' . $hsize .
		            '" halign="center" style="' . $style['HEADER'][0]['STYLE'][0] .
		            '" substyle="' . $style['HEADER'][0]['SUBSTYLE'][0] . '"/>' . LF;
		$isize = $hsize;
		$xml .= '<quad pos="-0.055 -0.045 -0.2" size="' . $isize . ' ' . $isize .
		            '" halign="center" valign="center" image="http://koti.mbnet.fi/reaby/xaseco/images/ts3logo.jpg" />' . LF;
		$xml .= '<label pos="-0.10 -0.025 -0.2" size="' . ($widths[0]-0.12) . ' ' . $hsize .
		            '" halign="left" style="' . $style['HEADER'][0]['TEXTSTYLE'][0] .
		            '" text="' . htmlspecialchars(validateUTF8String($header)) . '"/>' . LF;
		
		//add body
		$xml .= '<quad pos="-' . ($widths[0]/2) . ' -' . (0.02+$hsize) .
		            ' -0.1" size="' . ($widths[0]-0.02) . ' ' . (0.02+$lines*$bsize) .
		            '" halign="center" style="' . $style['BODY'][0]['STYLE'][0] .
		            '" substyle="' . $style['BODY'][0]['SUBSTYLE'][0] . '"/>' . LF;
		
		
		$cnt = 1;
		unset($message);
		$users = $this->tsstatus->_serverDatas['virtualserver_clientsonline'];
		$users = $users - 1;
		$max = $this->tsstatus->_serverDatas['virtualserver_maxclients'];
		$channels = 0;
		foreach ($this->tsstatus->_channelDatas as $channel) {$channels++;}
		
		$message[] .= "\$fff Server: ".$ts3_settings['server_addr'];
		$message[] .= "\$fff Users: ".$users." / ".$max;
		$message[] .= "\$fff Channels: ".$channels;
		
		foreach ($message as $info) {
			$xml .= '<label pos="-0.025 -' . ($hsize-0.008+$cnt*$bsize) .
			               ' -0.2" size="' . ($widths[0]-0.04) . ' ' . (0.02+$bsize) .
			               '" halign="left" style="' . $style['BODY'][0]['TEXTSTYLE'][0] .
			               '" text="' . htmlspecialchars(validateUTF8String($info)) . '"/>' . LF;
			$cnt++;
		}
		//join server button
		$xml .='<frame  pos="-' . ($widths[0]/2) . ' -' . ($hsize-0.008+20*$bsize) .' -0.1">';
		$cnt+1;
		$xml .='<label posn="-29 0 0.3" style="CardButtonMedium" text="Join server" url="'.$ts3_settings['helperURL'].'?server='.$ts3_settings['server_addr'].'&amp;port='.$ts3_settings['serverport'].'&amp;channel='.$ts3_settings['channel'].'&amp;subchannel='.$ts3_settings['subchannel'].'&amp;channelpassword='.$ts3_settings['channelpassword'].'" addplayerid="1"/>';
		
		$xml .='</frame>';
		
		//draw Teamspeak channelbox
		$xml .='<frame  pos="-0.825 -' . ($hsize-0.008+1*$bsize) .' 0.1">
		      <quad sizen="40 58" posn="0 0 0.001" style="BgsPlayerCard" substyle="BgPlayerName"/>';
		
		foreach ($this->tsstatus->_channelDatas as $data) {
			$stats[$data["cid"]]["name"] = $data["channel_name"];
		}
		
		foreach ($this->tsstatus->_userDatas as $data) {
			if (!strstr($data['client_nickname'],"Unknown")) {
				$stats[$data["cid"]]["players"][] = array("name" => $data['client_nickname']);
			}
		}
		
		unset($cnt);
		$cnt = 1;
		$xml .='<format textsize="1" />';
		
		foreach ($stats as $info) {
			if ($cnt > 20) break;
			$xml .= '<label pos="-0.025 -' . (0.01+$cnt*0.03) . ' -0.2" halign="left" text="$090' . htmlspecialchars(validateUTF8String($info['name'])) . '"/>' . LF;
			$cnt++;
			
			if ( count($info['players']) > 0 ) {
				foreach ($info['players'] as $players) {
					$xml .= '<label pos="-0.045 -' . (0.01+$cnt*0.03) . ' -0.2" halign="left" text="' . htmlspecialchars(validateUTF8String($players['name'])) . '"/>' . LF;
					$cnt++;
				}
			}
		}
		$xml .='</frame>';
		
		// add button (action "0" = close) & footer
		$xml .= '<quad pos="-' . ($widths[0]/2) . ' -' . (0.04+$hsize+$lines*$bsize) .
		            ' -0.2" size="0.06 0.06" halign="center" style="Icons64x64_1" substyle="Close" action="'.($this->manialinkID+2).'"/>' . LF;
		$xml .= '</frame>';
		$xml = str_replace('{#black}', $style['WINDOW'][0]['BLACKCOLOR'][0], $xml);
		
		$xml .='
		            </manialink>
		            </manialinks>';
		
		$this->Aseco->addCall('SendDisplayManialinkPageToLogin', array($login, $xml, 0, false));
	}
	
	function info_off($login) {
		$xml = '<?xml version="1.0" encoding="UTF-8"?><manialinks><manialink id='.($this->manialinkID+4).'></manialink></manialinks>';
		$this->Aseco->addCall('SendDisplayManialinkPageToLogin', array($login, $xml, 0, false));
	}
}
?>