<?php 
$login = $_GET['playerlogin'];
$server = $_GET['server'];
$port = $_GET['port'];
$channel = $_GET['channel'];
$subchannel = $_GET['subchannel'];
$channelpassword = $_GET['channelpassword'];

	// teamspeak://IP_or_DNS:PORT?nickname=YourNickname?loginname=You rLoginName?password=YourPassword?channel=ChannelNa me?channelpassword=PasswordOfChannel?subchannel=Yo urSubchannel
	header("location: ts3server://$server?nickname=$login&port=$port&channel=$channel&channelpassword=$channelpassword&subchannel=$subchannel");


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
